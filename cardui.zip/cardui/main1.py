from nicegui import ui
from schema_data import card_data
from form_schema import form_data

def show_dynamic_form(schema: dict):
    with ui.dialog() as dialog:
        with ui.card().classes('p-6'):
            ui.label(schema['label']).classes('text-xl font-bold mb-4')
            controls = {}

            for key, field in schema['fields'].items():
                label = field['label']
                ftype = field['type']
                default = field.get('default', '')

                if ftype == 'string':
                    controls[key] = ui.input(label).props('outlined')
                    controls[key].value = default
                elif ftype == 'textarea':
                    controls[key] = ui.textarea(label).props('outlined')
                    controls[key].value = default
                elif ftype == 'integer':
                    controls[key] = ui.number(label)
                    controls[key].value = default
                elif ftype == 'slider':
                    controls[key] = ui.slider(min=field['min'], max=field['max']).props(f'label="{label}"')
                    controls[key].value = default
                elif ftype == 'dropdown':
                    controls[key] = ui.select(field['options'], label=label)
                    controls[key].value = default

            with ui.row().classes('justify-between mt-4'):
                ui.button('TEST MODEL', color='green')
                ui.button('SAVE MODEL', color='green')
                ui.button('CLOSE', color='blue', on_click=dialog.close)

        dialog.open()

def create_card(card: dict):
    fields = list(card['fields'].values())
    title = fields[0]['default'] if fields else ''

    def on_card_click():
        show_dynamic_form(form_data['model details_form'])

    with ui.card().classes('w-80 shadow-md bg-gray-50') as card_ui:
        if card.get('clickable'):
            card_ui.on('click', on_card_click)

        with ui.row().classes('justify-between items-center w-full'):
            ui.label(title).classes('text-green-700 font-semibold text-lg')
            with ui.row().classes('gap-2'):
                for icon in ['content_copy', 'download', 'delete']:
                    ui.icon(icon).classes('cursor-pointer text-red-600' if icon == 'delete' else 'cursor-pointer')

        for field in fields[1:]:
            ui.label(field['default']).classes('text-md text-gray-700 mt-2')

# ----------- Build Cards -----------
with ui.row().classes('gap-4 p-4'):
    for card in card_data.values():
        if card.get('type') == 'card':
            create_card(card)

ui.run()
