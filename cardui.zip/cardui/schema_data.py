# card_schema.py

card_data = {
    "model_card": {
        "label": "Model Preview Card",
        "type": "card",
        "clickable": True,
        "fields": {
            "label": {
                "label": "Model Name",
                "type": "string",
                "default": "OpenAI"
            },
            "description": {
                "label": "Description",
                "type": "string",
                "default": "Openai chat"
            },
            "timestamp": {
                "label": "Created",
                "type": "string",
                "default": "just now"
            }
        }
    },
    "gemini_card": {
        "label": "Gemini Preview Card",
        "type": "card",
        "clickable": True,
        "fields": {
            "label": {
                "label": "Model Name",
                "type": "string",
                "default": "Gemini"
            },
            "description": {
                "label": "Description",
                "type": "string",
                "default": "Google gemini"
            },
            "timestamp": {
                "label": "Created",
                "type": "string",
                "default": "just now"
            }
        }
    }
}
