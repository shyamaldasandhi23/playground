form_data = {
    "model details_form": {
        "label": "New Model Configuration",
        "type": "form",
        "fields": {
            "model_name": {
                "label": "Model Name",
                "type": "string",
                "default": ""
            },
            "azure_deployment": {
                "label": "Azure Deployment Name",
                "type": "string",
                "default": ""
            },
            "description": {
                "label": "Description",
                "type": "textarea",
                "default": ""
            },
            "max_retries": {
                "label": "Max Retries",
                "type": "integer",
                "default": 2
            },
            "temperature": {
                "label": "Temperature",
                "type": "slider",
                "min": 0,
                "max": 10,
                "default": 0
            },
            "api_version": {
                "label": "API Version",
                "type": "dropdown",
                "options": ["2023-05-15", "2024-01-01-preview", "2025-01-01-preview"],
                "default": "2025-01-01-preview"
            }
        }
    }
}
