import sys
from loguru import logger
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from typing import Any, Optional



def setLogConfig(
        service_name: str=" GenAI Platform",
        otlp_endpoint: str = "localhost:4317",
        app_name:str="app",
        log_file: str = "app.log",
        log_level: str = "DEBUG",
        log_format: str ="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
        rotation:str ="10 MB",
) -> Any:
    """Configure Loguru logger with console and OTLP output.

    Args:
        service_name: Name of the service
        otlp_endpoint: Endpoint for OTLP exporter
        app_name: Name of the application for logs
        log_level: Minimum log level to capture
    """
    # Configure log format
    #log_format ="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
    
    print ("log level", log_level)
    # Reset and configure logger
    logger.remove()

    # Add console handler
    logger.add(
        log_file,
        format=log_format,
        level=log_level,
        filter=None,
        colorize=None, 
        serialize=False, 
        backtrace=True, 
        diagnose=True, 
        enqueue=False, 
        context=None, 
        catch=True,   
        rotation="10 MB",  # Optional: rotates after 10MB
        compression="zip"  

    )

    # Add OTLP handler
    '''
    from loguru_otlp_handler import OTLPHandler
    otlp_handler = OTLPHandler(
        service_name=service_name,
        exporter=OTLPLogExporter(
            endpoint=otlp_endpoint,
            insecure=True
        )
    )
    logger.add(
        otlp_handler.sink,
        level=log_level
    )
    '''
    # Add default context
    logger.configure(
        extra={"appname": app_name}
    )
    return logger

