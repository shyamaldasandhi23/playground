import httpx

def call_api(base_url, endpoint, params=None, headers=None, method='POST', json_data=None):
    """
    Makes an API call with dynamic URL generation using httpx.

    Args:
        base_url (str): The base URL of the API.
        endpoint (str): The specific endpoint to call.
        params (dict, optional): Query parameters for the URL. Defaults to None.
        headers (dict, optional): HTTP headers. Defaults to None.
        method (str, optional): HTTP method (GET, POST, PUT, DELETE, etc.). Defaults to 'GET'.
        json_data (dict, optional): JSON data for POST/PUT requests. Defaults to None.

    Returns:
        httpx.Response: The response object from the API call.
    """

    url = f"{base_url}/{endpoint}"
    try:
        with httpx.Client() as client:
            if method == 'GET':
                response = client.get(url, params=params, headers=headers)
            elif method == 'POST':
                response = client.post(url, params=params, headers=headers, json=json_data)
            elif method == 'PUT':
                response = client.put(url, params=params, headers=headers, json=json_data)
            elif method == 'DELETE':
                 response = client.delete(url, params=params, headers=headers)
            else:
                raise ValueError("Invalid HTTP method")
            response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)

            return response.json()
    except httpx.HTTPError as e:
        print(f"HTTP Error: {e}")
        return None
    except ValueError as e:
        print(f"Value Error: {e}")
        return None
