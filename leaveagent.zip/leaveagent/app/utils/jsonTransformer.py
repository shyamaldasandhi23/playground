import jq
import json
from app.utils.manageAppLogger import setLogConfig
from loguru import logger


def jsonTransformer(query,input):
    
    converted_value=jq.text(query, input)
    logger.debug("converted value from JQ---- {}", converted_value)

    output=json.loads(converted_value)
    return output
