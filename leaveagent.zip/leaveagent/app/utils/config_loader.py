from app.utils.app_config import AppConfig

# Initialize AppConfig once and expose it as a singleton
app_config = AppConfig()

