import tiktoken
from leaveagent.app.utils.manageAppLogger  import setLogConfig

logger= setLogConfig()

def get_num_tokens(string: str, openai_model_name: str) -> int:
    """Calculate num tokens for OpenAI with tiktoken package.

    Official documentation: https://github.com/openai/openai-cookbook/blob/main
                            /examples/How_to_count_tokens_with_tiktoken.ipynb
    """
    tiktoken = tiktoken()

    encoding = tiktoken.encoding_for_model(openai_model_name)
    num_tokens = len(encoding.encode(string))
    return num_tokens


def manageTokenCountBeforeCall(modelName:str,prompt:str):

    token_count= get_num_tokens(prompt,modelName)

