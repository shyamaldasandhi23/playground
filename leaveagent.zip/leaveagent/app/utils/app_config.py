import sys
import yaml
import os
from loguru import logger
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.utils.manageAppLogger import setLogConfig
from app.db.dbModel import Base  # Replace 'models' with your actual models module


class AppConfig:
    def __init__(self, filename="config.yaml"):
        
        app_root = os.path.dirname(os.path.abspath(sys.argv[0]))
        config_path = os.path.join(app_root, filename)

        self.config = self._load_config(config_path)
        self._setup_logging()
        self.engine = self._setup_database()
        self._create_tables()
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

    def _load_config(self, path):
        with open(path, "r") as file:
            return yaml.safe_load(file)
        


    def _setup_logging(self):
        log_config = self.config.get("logging", {})
        logger=setLogConfig(
        service_name= log_config.get("service_name", "GenAI Platform"),
        otlp_endpoint= log_config.get("otlp_endpoint", "localhost:4317"),
        log_file=log_config.get("log_file", "app.log"),
        log_level = log_config.get("level", "INFO"),
        log_format= log_config.get("format", "{time} {level} {message}"),
        rotation = log_config.get("rotation", "10 MB")

        )

    def _setup_database(self):
        db_config = self.config.get("database", {})
        return create_engine(
            db_config.get("url"),
            echo=db_config.get("echo", False)
        )
    
    def _create_tables(self):
        # This will create all tables defined in your models if they don't exist
        Base.metadata.create_all(bind=self.engine)

    def get_session(self):
        return self.SessionLocal()

