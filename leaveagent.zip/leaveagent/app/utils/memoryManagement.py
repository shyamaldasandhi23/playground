from typing import Any
from langgraph.graph import MessagesState
from langchain_core.messages import RemoveMessage, AIMessage,HumanMessage,BaseMessage
from langgraph.graph import add_messages
from agent import Agent
from langchain_core.messages import trim_messages
from tiktoken import encoding_for_model
from leaveagent.app.utils.manageAppLogger import setLogConfig

logger = setLogConfig()
def summarize_conversation(save:Any, agent:Agent):

 
    summary_message = "Create a summary of the conversation above:"

    # Add prompt to our history
    input = add_messages(save["messages"],HumanMessage(content=summary_message))
    response = agent["llm"].invoke(input)
    print ("messages=======", save["messages"])
    print ("Summarised =========", response)

    # Delete all but the 2 most recent messages
    delete_messages = trim_messages(save["messages"],max_tokens=1000,
                                    token_counter=count_tokens,
                                    start_on="human",
                                    end_on=("human", "tool"),
                                    include_system=True,                                    
                                    )
    print ("after trim=======",delete_messages )
    if save["messages"] != delete_messages:
        finalMessages=add_messages(response,delete_messages)
        save["messages"]=finalMessages
        count_tokens(finalMessages)
        return save
    else:
        return save


def count_tokens(messages: list[BaseMessage]) -> int:
    
    encoding = encoding_for_model("gpt-3.5-turbo")  # Use as approximation for Llama
    num_tokens = 0
    for message in messages:
        num_tokens += len(encoding.encode(message.content))
        num_tokens += 4  # Approximate overhead per message
        
    logger.info("Get Number of Tokens At this Stage.......{} ", num_tokens)
    
    return num_tokens