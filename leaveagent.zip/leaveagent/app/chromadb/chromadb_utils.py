from llama_index.core import Settings
from llama_index.llms.azure_openai import AzureOpenAI
from llama_index.embeddings.azure_openai import AzureOpenAIEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.retrievers import QueryFusionRetriever
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core import VectorStoreIndex, StorageContext
import app.core.basicconfig as basicconfig
import chromadb
from llama_index.core import Settings
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.vector_stores import MetadataFilters,FilterOperator
from importlib import import_module



basicconfig

Settings.llm = AzureOpenAI(
    azure_deployment="CHROMA-GPT35",  # or your deployment
    api_version="2025-01-01-preview",  # or your api version
    timeout=60,
    temperature=0,
    max_retries=2
    # other params...
)
Settings.embed_model = AzureOpenAIEmbedding( api_version="2025-01-01-preview",
                                            azure_deployment="text-embedding-3-large"
                                            )

def persistToChromadbInstance(nodes,collection_name,db_name,filters=None):
    
    docstore = SimpleDocumentStore()
    docstore.add_documents(nodes)
    db = chromadb.PersistentClient(path=db_name)
    chroma_collection = db.get_or_create_collection(collection_name)
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    storage_context = StorageContext.from_defaults(
    docstore=docstore, vector_store=vector_store
    )
    
    index = getChromadbPersistedInstance(collection_name,db_name)
    if index is None:        
        index = VectorStoreIndex(nodes=nodes, storage_context=storage_context,
                             embed_model=Settings.embed_model)
    else:   
        list_filter_criteria=[]
        module = import_module("."+"vector_stores","llama_index.core")

        for key, value in filters.items():
            list_filter_criteria.append(getattr(module, "MetadataFilter")(key=key,value=value,operator=FilterOperator.EQ))
        
        filtercondition="and"

        filters = MetadataFilters(filters=
            list_filter_criteria, filtercondition=filtercondition
        ) 
        indexretriever = index.as_retriever(similarity_top_k=1000,filters=filters )
        source_nodes=indexretriever.retrieve("fake")
        node_ids = [x.node.node_id for x in source_nodes]
        if len(node_ids) >0 :
            index.delete_nodes(node_ids=node_ids)
        index.insert_nodes(nodes)

    return index

def getChromadbPersistedInstance(collection_name,db_name):

    db2 = chromadb.PersistentClient(path=db_name)
    chroma_collection = db2.get_or_create_collection(collection_name)
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    docstore = SimpleDocumentStore()
    storage_context = StorageContext.from_defaults(
    docstore=docstore, vector_store=vector_store
    )
    index = VectorStoreIndex.from_vector_store(
        vector_store,
        embed_model=Settings.embed_model,storage_context=storage_context
    )
    return index


def deleteFromChromaDB():

    db_name ="C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db"
    collection_name ="resume_summary_vector"

    index = getChromadbPersistedInstance(collection_name,db_name)

    indexretriever = index.as_retriever(similarity_top_k=20000)
    source_nodes=indexretriever.retrieve("fake")
    if source_nodes != None:
        nodes = [x.node.node_id for x in source_nodes]
        print ("nodes--------------->", nodes)
        index.delete_nodes(node_ids=nodes)
    

