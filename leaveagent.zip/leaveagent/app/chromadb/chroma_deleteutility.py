from chromadb_utils import deleteFromChromaDB




deleteFromChromaDB()