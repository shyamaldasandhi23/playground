
from llama_index.core import SimpleDirectoryReader
from llama_index.core.node_parser import SentenceSplitter
from llama_index.retrievers.bm25 import BM25Retriever
from llama_index.core import VectorStoreIndex, StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core.retrievers import QueryFusionRetriever
from chromadb_utils import persistToChromadbInstance
from llama_index.core.node_parser import (
    SentenceSplitter,
    SemanticSplitterNodeParser,
    SemanticDoubleMergingSplitterNodeParser,
    LanguageConfig
)

from chromadb_utils import Settings
import Stemmer
import basicconfig

basicconfig


documents = SimpleDirectoryReader(input_files=["C:\\Users\\Mahesh\\work\\agenticplatform\\resume John Doe.txt"],
                                  ).load_data()

#"C:\\Users\\Mahesh\\work\\agenticplatform\\offerletterJuan.txt"
metadata= {"candidate_name":"John Doe", "tenant_id":"1212"}
#metadata= {"candidate_name":"Juan Pérez", "offer_id":"111212"}
#metadata= {"candidate_name":"Mary Gomez", "offer_id":"666"}
documents[0].metadata=metadata
splitter = SentenceSplitter(chunk_size=100, chunk_overlap=20)
'''
splitter = SemanticSplitterNodeParser(
    buffer_size=1, breakpoint_percentile_threshold=95, embed_model=Settings.embed_model,
    #sentence_splitter=sentenceSplitter
)

'''
'''
config = LanguageConfig(language="english", spacy_model="en_core_web_md")
splitter = SemanticDoubleMergingSplitterNodeParser(
    language_config=config,
    initial_threshold=0.4,
    appending_threshold=0.5,
    merging_threshold=0.5,
    max_chunk_size=5000,
)
'''
nodes = splitter.get_nodes_from_documents(documents)
db_name ="C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db"
#collection_name ="demo_vector"
collection_name ="resume_vector"

persistToChromadbInstance(nodes,collection_name,db_name,metadata)

# We can pass in the index, docstore, or list of nodes to create t