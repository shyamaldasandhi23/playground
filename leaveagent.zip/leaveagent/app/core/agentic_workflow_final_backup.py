from importlib import import_module
from typing import Any
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import BaseMessage
from langgraph.func import entrypoint, task
from langgraph.graph import add_messages
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore
from langgraph.store.base import BaseStore
from agent_llm import createAgentWithTools
from langgraph.types import interrupt
from agent import Agent
from app.utils.utilsForMessageDisplay import string_to_uuid
from app.chromadb.chromadb_utils import getChromadbPersistedInstance
from agent_tasks import call_model, call_task_orchestrator
from app.utils.memoryManagement import summarize_conversation

from loguru import logger


@entrypoint(checkpointer=MemorySaver(), store=InMemoryStore())
def workflow(
    messages: list[BaseMessage],    
    previous: Any,
    config: RunnableConfig,
    store: BaseStore,
   ):
    
    logger.info("Main WorkfLow")
    workflowConfig=config["configurable"]["workflow"]

    profileData={}
    if "profileData" in config["configurable"] and config["configurable"]["profileData"] != None:
        profileData = config["configurable"]["profileData"]
    else:
        profileData = getProfileData()    

    crewagentlist= []
    for agentdata in workflowConfig:
        agent= setupWorkflow(agentdata,profileData)
        if agent["type"]=="primary" :
            primaryagent=agent  
        else:
            crewagentlist.append(agent) 

    if previous is not None:
        messages = add_messages(previous["messages"], messages)
    else :
        messages= add_messages([],messages)

    save=previous
    while True:
        if save is None or save["type"]=="primary":
            logger.info("Processing Primary")
            response = processAgent(primaryagent,messages,store).result()
            logger.debug("Process Agent --Primary-------{} ",response )

            save= {"messages":add_messages(messages, response["llm_response"]),
                        "agent_name":primaryagent["name"], "type":primaryagent["type"]}

            if "type" in response["tooldata"]  and  response["tooldata"]["type"]=="assistanthandover":
                
                for crew in crewagentlist:
                    if crew["name"]==response["tooldata"]["assistant_name"]:
                        response =processAgent(crew,messages,store).result()
                        if "type" in response["tooldata"]  and response["tooldata"]["type"]=="masterhandover":
                            messages=add_messages(messages, response["llm_response"])
                            save= {"messages":messages,
                                    "agent_name":primaryagent["name"], "type":primaryagent["type"]}
                        else:
                            messages=add_messages(messages, response["llm_response"])
                            save= {"messages":messages,
                            "agent_name":crew["name"], "type":crew["type"]}
                        break
            else:
                return entrypoint.final(value=response["llm_response"], save=save)
                
        else:
            if save["type"]=="crew":
                logger.info("Processing Crew")
                for crew in crewagentlist:
                    if save["agent_name"] ==crew["name"]:
                        response = processAgent(crew,messages,store).result()
                        logger.debug("Process Agent --crew-------{} ",response )
                        messages=add_messages(messages, response["llm_response"])

                        save= {"messages":messages,
                            "agent_name":crew["name"], "type":crew["type"]}
                    
                        if "type" in response["tooldata"]  and response["tooldata"]["type"]=="masterhandover":

                            response =processAgent(primaryagent,messages,store).result()
                            if response["llm_response"].tool_calls:
                                messages=add_messages(messages, response["llm_response"])

                                save= {"messages":messages,
                                    "agent_name": response["tooldata"]["assistant_name"],"type":"crew"}
                                    
                            else:   
                                messages=add_messages(messages, response["llm_response"])
                                save= {"messages":messages,
                                    "agent_name":primaryagent["name"], "type":primaryagent["type"]}
                            break
                        else: 
                            return entrypoint.final(value=response["llm_response"], save=save)
  

        if  "type" in response["tooldata"] :
            if response["tooldata"]["type"] not in ("masterhandover" , "assistanthandover"):
                #print ("exitinv---", response["llm_response"] )    
                #save=summarize_conversation(save ,agent)
                return entrypoint.final(value=response["llm_response"], save=save)

        else:
            #print ("exitinv---", response["llm_response"] )    
            #save=summarize_conversation(save ,agent)

            return entrypoint.final(value=response["llm_response"], save=save)


def setupWorkflow(agentdata:dict, profileData:dict):
    agent=Agent()
    agent=createAgentWithTools(agentdata)
    agent["tools"]=agentdata["agent"]["tools"]
    agent["type"]=agentdata["agent"]["type"]
    agent["name"]=agentdata["agent"]["name"]
    agent["profileData"]= profileData
    return agent

@task    
def processAgent(agent:Agent,messages:BaseMessage,store: InMemoryStore):
    
    logger.info("Process Agent ----Agent Name ---{} ",agent["name"] )
    llm_response = call_model(agent,messages,store).result()
    

    while True: 
        tooldata={}

        if not llm_response.tool_calls:  
            break
        # Execute tools
        tool_result_futures = [call_task_orchestrator(tool_call,agent,messages,store) for tool_call in llm_response.tool_calls]
        
        tool_results = [fut.result() for fut in tool_result_futures]

        # Append to message list
        messages = add_messages(messages, [llm_response, tool_results[0]["message"]])

        # Call model again
        llm_response = call_model(agent,messages,store).result()
        tooldata=tool_results[0]["tooldata"]

        if tooldata["type"]=="assistanthandover":
            break
        if tooldata["type"]=="masterhandover":
            break


    return {"tooldata":tooldata,"llm_response":llm_response}

def getProfileData():
    return None

