from typing import TypedDict
from langchain_core.language_models.base import BaseLanguageModel


class Agent(TypedDict):

    name:str
    llm: BaseLanguageModel
    tools:dict
    type:str
    prompt:object
    profileData:dict
    tool_concurrency:int

