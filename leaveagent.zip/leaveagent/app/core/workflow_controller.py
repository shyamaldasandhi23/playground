from importlib import import_module
from typing import Any
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import BaseMessage
from langgraph.func import entrypoint, task
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore
from langgraph.store.base import BaseStore
from langgraph.types import interrupt
from app.core.agent import Agent
from app.core.workflows_agentic import processAgenticWorkflow
from app.core.workflow_predefined import processWorkflow
from opentelemetry.sdk.trace.export import ConsoleSpanExporter
import os
from traceloop.sdk import Traceloop 
from app.configs import configLeaveAgent,configOfferLetterQAAgent,configResumeMatchingAgentic,configResumeSkillExperienceSummary,configResumeScoreMatching,configResumeMatchingAdvanced
import sqlite3
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.store.sqlite import SqliteStore
from loguru import logger


conn = sqlite3.connect("checkpoints.sqlite", check_same_thread=False)
checkpointer = SqliteSaver(conn)
store = SqliteStore(conn)



logs_dir = "C:\\Users\\Mahesh\\work\\"
langtrace_logs_dir = os.path.join(logs_dir, "agenticplatform")
traceloop_log_file_path = os.path.join(langtrace_logs_dir, "traceloop_issue_example.log")
traceloop_log_file = open(traceloop_log_file_path, "w")

# Initialize Traceloop with ConsoleSpanExporter
exporter = ConsoleSpanExporter(out=traceloop_log_file)
Traceloop.init(disable_batch=True, exporter=exporter)



@entrypoint(checkpointer=checkpointer, store=store)
def workflow(
    messages: list[BaseMessage],    
    previous: Any,
    config: RunnableConfig,
    store: BaseStore,
   ):
    
    logger.info("Main WorkfLow")

    llm_package_name = "app.configs"
    llm_module_name=config["configurable"]["workflow"]
    module = import_module("."+llm_module_name,llm_package_name)

    workflowConfig=getattr(module, "workflow")    

    profileData={}
    if "profileData" in config["configurable"] and config["configurable"]["profileData"] != None:
        profileData = config["configurable"]["profileData"]
    else:
        profileData = getProfileData()    

    if workflowConfig["type"]=="agentic":
        agent_config= workflowConfig["agents"]  
        logger.debug("agent config-------{}",agent_config )
        logger.debug("Profile data-------{}",profileData )

        workflow_response=processAgenticWorkflow(messages=messages,previous=previous,agent_config=agent_config,profileData=profileData,store=store).result()
        return entrypoint.final(value=workflow_response["value"], save=workflow_response["save"])
    else:
        if workflowConfig["type"]=="workflow" and workflowConfig["mode"]=="predefined":
            tooldata={}
            tool_call={}
            tooldata=workflowConfig
            tool_call["args"]=config["configurable"]["profileData"]    
            agent= Agent()
            agent["name"]=workflowConfig["type"]
            agent["type"]=workflowConfig["mode"]
            workflow_response=processWorkflow(tooldata,tool_call,agent, store).result()
            return entrypoint.final(value=workflow_response["value"], save=workflow_response["save"])

def getProfileData():
    return None

