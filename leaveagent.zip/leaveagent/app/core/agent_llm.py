from datetime import date, datetime
import app.core.basicconfig
from langchain_core.prompts import ChatPromptTemplate
from importlib import import_module
from app.core.agent import Agent


def createLLMObject(llmconfig,llmattr)-> object:
    
    try:
        if "llm_pkg_name" in llmconfig and llmconfig.get("llm_pkg_name") !="":
            module = import_module("."+llmconfig["llm_module_name"],llmconfig["llm_pkg_name"])
        else:
            module = import_module(llmconfig["llm_module_name"])

        llm=getattr(module, llmconfig["llm_class_name"])(**llmattr)

    except Exception as e:
        print(e)
        raise Exception(e)
    return llm


def createAgentWithTools(agentdata:dict):
    agent = Agent()
    llm=createLLMObject(agentdata["agent"]["llmconfig"], agentdata["agent"]["llmattr"]  ) 
    systemPrompt=agentdata["agent"]["prompt"]
    prompt= ChatPromptTemplate.from_messages(
        [("system","{systemPrompt}")]).partial(systemPrompt=systemPrompt)
    agent["prompt"]= prompt.format_messages(time=datetime.now)
    tool = agentdata["agent"]["tools"]
    tooldesc=tool["toolsdesc"]
    agent["llm"] = llm.bind_tools(tooldesc)

    return agent



