import os
from langchain_openai import OpenAIEmbeddings

os.environ["AZURE_OPENAI_ENDPOINT"] = "https://openai-chroma-poc-swc.openai.azure.com/"
os.environ["AZURE_ENDPOINT"] = "https://openai-chroma-poc-swc.openai.azure.com/"

os.environ["AZURE_OPENAI_API_KEY"] = "72bb04788cc94eba9040ee4dfe6a417c"
os.environ["OPENAI_API_KEY "] = "72bb04788cc94eba9040ee4dfe6a417c"

