from importlib import import_module
from langchain_core.messages import ToolMessage
from langchain_core.tools import tool
from llama_index.retrievers.bm25 import BM25Retriever
from app.chromadb.chromadb_utils import getChromadbPersistedInstance, Settings
from llama_index.core.retrievers import QueryFusionRetriever
from llama_index.core import get_response_synthesizer
from llama_index.core.postprocessor import SimilarityPostprocessor
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.vector_stores import MetadataFilter, MetadataFilters,FilterOperator
from loguru import logger


'''
def getLeaveBalance() -> str:
    """
    """
    return f"leave balance for employee {employee_id} is 15 days."
'''

@tool("check_weather")
def check_weather(location: str) -> str:
    '''   
    '''
    return f"It's always sunny in {location}"

@tool("validate_Leave_Balance_For_Request")
def validate_Leave_Balance_For_Request( leave_balance:str,required_leave_days:str) -> str:
    '''   
    '''
    if int(leave_balance) > int(required_leave_days):
        return f"employee can apply leave of {required_leave_days} since he has leave balance of {leave_balance}"
    else:
        return f"employee can not apply leave of {required_leave_days} since he has leave balance of {leave_balance}"

     

@tool("apply_For_Leave_After_Validation")
def apply_For_Leave_After_Validation( required_leave_days:str) -> str:
    '''   
    '''
    return f"leaves applied for  {required_leave_days} days"


@tool("get_job_description")
def get_job_description(file_name) -> str:
    '''   
    '''
    from llama_index.core import SimpleDirectoryReader
    print ("inside get job description")
    documents = SimpleDirectoryReader(input_files=[
        #"C:\\Users\\Mahesh\\work\\agenticplatform\\jd for java architect.txt"
        #"C:\\Users\\Mahesh\\work\\agenticplatform\\jd for Gen AI architect.txt"
        file_name
        ]
        ).load_data()

    return documents[0].get_content()


@tool("get_offer_letter_id")
def get_offer_letter_id(candidate_name:str) -> dict:
    '''   
    '''
    if candidate_name =="Mary":
        return {"candidate_name":"Mary Gomez", "offer_id":"666"}

    else:    
        return {"candidate_name":"Juan Pérez", "offer_id":"111212"}
    
 


'''
#@tool("offer_letter_info_retriever")
def offer_letter_info_retriever(query:str,candidate_name:str,offer_id:str) -> str:
    """
    """
    #tenant_id
    #offer_letter_id

    db_name ="C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db"
    collection_name ="demo_vector"
    index = getChromadbPersistedInstance(collection_name=collection_name,db_name=db_name)
    if candidate_name =="Juan Pérez":
        filters = MetadataFilters(filters=[
        MetadataFilter(key="name", value="Juan Pérez", operator=FilterOperator.EQ),
        MetadataFilter(key="offer_id", value="111212", operator=FilterOperator.EQ),

    ])
    else:
    
        filters = MetadataFilters(filters=[
        MetadataFilter(key="name", value="Mary Gomez", operator=FilterOperator.EQ),
        MetadataFilter(key="offer_id", value="666", operator=FilterOperator.EQ),

    ])
    tool_call={}
    tool_call["args"] ={"name":candidate_name,"offer_id":offer_id}
    filter_data = tool_call["args"]
    list_filter_criteria = []
    module = import_module("."+"vector_stores","llama_index.core")
        
    for key, value in filter_data.items():
        list_filter_criteria.append(getattr(module, "MetadataFilter")(key=key,value=value,operator=FilterOperator.EQ))
    
    filters = MetadataFilters(filters=
        list_filter_criteria
    )
    
    retriever = index.as_retriever(similarity_top_k=2, filters=filters)

    nodes = retriever.retrieve(query)

    response =""
    for node in nodes:
        response = response + node.get_text()

    if response != "":
         response = f"Following is the information extracted from Offer Letter {response}"
    else:
         response =  f"No information found in offer letter or candidate offer letter doesn't exist"

    return response

#text = offer_letter_info_retriever("What is my probation period","Mary Gomez","666")
#print("text---------->", text)
'''