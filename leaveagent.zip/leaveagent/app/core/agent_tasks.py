from importlib import import_module
from langgraph.func import  task
from langgraph.graph import add_messages
from langgraph.store.base import BaseStore
from langchain_core.messages import ToolMessage, SystemMessage
from pydantic_core import ValidationError
from app.core.agent_tools import ( check_weather,get_job_description,
validate_Leave_Balance_For_Request,apply_For_Leave_After_Validation,get_offer_letter_id)
from langgraph.types import interrupt
from app.core.agent import Agent
from app.chromadb.chromadb_utils import getChromadbPersistedInstance
from llama_index.core.vector_stores import MetadataFilters,FilterOperator
from app.utils.utilsForRestapi import call_api
from app.utils.jsonTransformer import jsonTransformer
from app.core.agent_llm import createLLMObject
from app.chromadb.chromadb_utils import persistToChromadbInstance
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core import Document
from llama_index.core.schema import TextNode
import json
from loguru import logger

    
@task
def call_local_tool(tooldata,tool_call,agent:Agent, memory_store: BaseStore):
    
    logger.info("Call Local Tool ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])
    print("call_local_tool")

    try:
        print("call_local_tool")

        tools=[check_weather,get_offer_letter_id,get_job_description
            ,validate_Leave_Balance_For_Request,apply_For_Leave_After_Validation]
        print("call_local_tool")
        tools_by_name = {tool.name: tool for tool in tools}
        tool = tools_by_name[tooldata["name"]]
        if "args" in tool_call:
            print(tool_call)
            observation = tool.invoke(tool_call["args"])
        else:

            observation = tool.invoke(input=None)  
        
    except ValidationError as e:
        return {"tooldata": tooldata,
            "message":ToolMessage(
                content=f"Error: {e} \n please fix your mistakes.",
                tool_call_id=tool_call["id"])}

    if "id" in tool_call :

        return {"tooldata": tooldata,
            "message": ToolMessage(content=observation, tool_call_id=tool_call["id"])}
    else:
        return observation

@task
def call_App_tool(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    logger.info("Call App Tool ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])

    data=[tooldata, tool_call,agent["profileData"]]
    
    json_data=jsonTransformer(tooldata["jsontransformer"],data)

    base_url=tooldata["base_url"]
    endpoint=tooldata["end_point"]
    method=tooldata["method"]
    observation = call_api(base_url, endpoint, method=method, json_data=json_data)

    if "id" in tool_call :

        return {"tooldata": tooldata,
            "message": ToolMessage(content=observation, tool_call_id=tool_call["id"])}
    else:
        return observation


@task
def handoverprocessor(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    logger.info("Handover processor ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])

    content=tooldata["toolmessage"]
    return {"tooldata": tooldata,
            "message": ToolMessage(content=content, tool_call_id=tool_call["id"])}

@task
def llmToolCall(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    logger.info("LLM Task processor ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])

    llm=createLLMObject(tooldata["llmconfig"], tooldata["llmattr"]  ) 

    content=""
    items = tool_call.items()
    for k,v in items:

        content += f'{k } \n  {v} \n'
        
    if "message" in tooldata:
        final_content=     tooldata["message"] + content
    else:
        final_content = content

    logger.debug("LLM Task processor ----Agent Name ---{} \n Tool Name ----{} \n prompt ------{}",agent["name"],tooldata["name"], final_content)

    response = llm.invoke(final_content)

    if "id" in tool_call :
        return {"tooldata": tooldata,
            "message": ToolMessage(content=response, tool_call_id=tool_call["id"])}
    else :
        return response.content



@task
def vectorSearchToolCall(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    logger.info("Call RAG Tool ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])
    logger.debug("tool_call-----------{} ", tool_call)
    db_name =tooldata["db_id"]
    collection_name =tooldata["collection_id"]
    index = getChromadbPersistedInstance(collection_name=collection_name,db_name=db_name)
    data=[]
    if "profileData" in agent:
        data=[tooldata, tool_call,agent["profileData"]]
        logger.debug("Profile data {}", agent["profileData"])
    else:
        data= [tooldata, tool_call]    
    
    logger.debug("data before transformation----------{}", data)


    query=""
    if "query" in tooldata and  tooldata["query"]  !="":
        query= tooldata["query"]
    else:
        query=tool_call["args"]["query"]

    #filter_data = tool_call["args"]["metadata"]
    list_filter_criteria = []
    module = import_module("."+"vector_stores","llama_index.core")

    filters =None
    if "filtertransformer" in tooldata:
        filter_data=jsonTransformer(tooldata["filtertransformer"],data)
    
        for key, value in filter_data.items():
            list_filter_criteria.append(getattr(module, "MetadataFilter")(key=key,value=value,operator=FilterOperator.EQ))
        
        filtercondition="and"
        if "filtercondition" in tooldata:
            filtercondition=tooldata["filtercondition"]

        filters = MetadataFilters(filters=
            list_filter_criteria, filtercondition=filtercondition
        )
        logger.debug("filter data for accesing exact vector store {}", filter_data)

    logger.debug("query for seraching in vectore store {}", query)

    similarity_top_k = 4
    if "top_k" in tooldata:
        similarity_top_k=tooldata["top_k"]

    retriever = index.as_retriever(similarity_top_k=similarity_top_k, filters= filters)
    nodes = retriever.retrieve(query)

    result_text=""
    result_nodes=[]
    for node in nodes:
        result_text = result_text + node.get_text()
        result_node={"node":{"metadata":node.metadata , "id":node.node_id,
                             "score":node.get_score(),"text":node.get_text() }}
        result_nodes.append(result_node)
    
    if "id" in tool_call :
        if result_text != "":
         
         response = {"tooldata": tooldata, "message" :ToolMessage(content=f"Following is the information extracted  {result_text}",
                                                                  tool_call_id=tool_call["id"])}
        else:
         response =  {"tooldata": tooldata, "message" :ToolMessage(content=f"No information was found ",
                                                                tool_call_id=tool_call["id"])}
    else:
        response= {"nodes":result_nodes,"result_text":result_text} 
    return response     
    

@task
def human_feedback(message):
    logger.info("Human Feedback -----")


    """Append user input."""
    user_input = interrupt(message)
    '''
    human_message = {
                "role": "user",
                "content": message +"#"+ user_input,
                "id": string_to_uuid(user_input),
            }
    '''
    return user_input

@task
def VectorUploadtoolcall(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    db_name =tooldata["db_id"]
    collection_name =tooldata["collection_id"]
    if "profileData" in agent:
        data=[tooldata, tool_call,agent["profileData"]]
        logger.debug("Profile data {}", agent["profileData"])
    else:
        data= [tooldata, tool_call]    
    
    logger.debug("data before transformation----------{}", data)
    metadata=jsonTransformer(tooldata["metadatatransformer"],data)

    node = TextNode(
    text=tool_call["text"],
    metadata=metadata,
    )

    persistToChromadbInstance([node],collection_name,db_name,filters=metadata)