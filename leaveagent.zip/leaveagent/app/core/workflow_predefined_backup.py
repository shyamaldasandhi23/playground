from leaveagent.app.utils.manageAppLogger import setLogConfig
from agent_tasks import (ragToolCall,llmToolCall,call_local_tool,call_App_tool,
                         handoverprocessor,human_feedback)
from langgraph.func import entrypoint, task
from leaveagent.app.utils.jsonTransformer import jsonTransformer
from agent import Agent
from langgraph.store.base import BaseStore
from langchain_core.messages import ToolMessage

logger = setLogConfig()

@task
def processWorkflow(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    logger.info("LLM Task processor ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])


    tool_call_master={}  
    tool_call_master["input"]=tool_call["args"]

    task_nodes=tooldata["task_nodes"]
    prev_node="start"
    for task_node in task_nodes:

        if task_node["prev_node"]==prev_node:
            logger.info("Tool Name ---------", task_node)

            toolcalltransformer =task_node["tool_call_transformer"]
            if toolcalltransformer !="":
            
                tool_call_args=jsonTransformer(toolcalltransformer,tool_call_master)   
            

            if  task_node["interrupt"] :
                feedback=human_feedback(task_node["interrupt_message"]).result()
                logger.debug("processWorkflow ----Agent Name ---{} ,  interrupt_message---{} ",
                            agent["name"], tooldata["interrupt_message"])
                logger.debug("Tool Message-----{} \n",
                            feedback )

                if feedback=="No":
                    exit()

            if task_node["type"]=="vectorsearchtool":
                tool_call_master[task_node["name"]]= ragToolCall(task_node,tool_call_args,agent, memory_store).result() 
                logger.debug("processWorkflow ----Agent Name ---{}, tool name-----{} ",
                            agent["name"],task_node["name"] )
                logger.debug("Tool Message-----{} \n",
                            tool_call_master[task_node["name"]] )
            
            if task_node["type"]=="llmtool":
                tool_call_master[task_node["name"]]= llmToolCall(task_node,tool_call_args,agent, memory_store).result() 
                logger.debug("processWorkflow ----Agent Name ---{}, tool name-----{} ",
                            agent["name"],task_node["name"] )
                logger.debug("Tool Message-----{} \n",
                            tool_call_master[task_node["name"]] )
            
            if task_node["type"]=="apptool":
                tool_call_master[task_node["name"]] = call_App_tool(task_node,tool_call_args,agent, memory_store).result() 
                logger.debug("processWorkflow ----Agent Name ---{}, tool name-----{} ",
                            agent["name"],task_node["name"] )
                logger.debug("Tool Message-----{} \n",
                            tool_call_master[task_node["name"]] )

            
            if task_node["type"]=="tool":
                tool_call_master[task_node["name"]] = call_local_tool(task_node,tool_call_args,agent, memory_store).result() 
                logger.debug("processWorkflow ----Agent Name ---{}, tool name-----{} ",
                            agent["name"],task_node["name"] )
                logger.debug("Tool Message-----{}  \n",
                            tool_call_master[task_node["name"]] )

            
            prev_node=task_node["name"]
       
    output=None
    print (tooldata)
    if  "output_transformer" in tooldata :
        output_transformer =  tooldata["output_transformer"] 
        logger.debug("output_transformer-----{}  \n",
                            output_transformer )

        output=jsonTransformer(output_transformer,tool_call_master)
        logger.debug("Final output-----{}  \n",
                            output )

    else:  
        print (" you are in else")     
        output=tool_call_master[prev_node]

    if "id" in tool_call :

        return {"tooldata": tooldata,
            "message": ToolMessage(content=output, tool_call_id=tool_call["id"])}
    else:
        return {"value":output, "save":output}
