from app.core.agent_tasks import (vectorSearchToolCall,llmToolCall,call_local_tool,call_App_tool,
                         VectorUploadtoolcall,human_feedback)
from langgraph.func import entrypoint, task
from app.utils.jsonTransformer import jsonTransformer
from app.core.agent import Agent
from langgraph.store.base import BaseStore
from langchain_core.messages import ToolMessage
from loguru import logger

@task
def processWorkflow(tooldata,tool_call,agent:Agent, memory_store: BaseStore):

    logger.info("LLM Task processor ----Agent Name ---{} , Tool Name ----{} ",agent["name"],tooldata["name"])


    tool_call_master={}  
    tool_call_master["input"]=tool_call["args"]
    task_nodes=[]
    task_nodes=tooldata["task_nodes"]
    processed_list=[]
    prev_node_list=[]
    prev_node_list.append("start")
    tasknodes=[]
    edge_defn=tooldata["edge_defn"]
    tool_input_transformer=tooldata["input_transformer"]
    i=0
    while i < len(task_nodes): 
        tasknodes.clear()
        for task_node in task_nodes:
            print ("edge_defn task_node name]---------->", edge_defn[task_node["name"]])
            print ("prev_node_list", prev_node_list)
            if not set([task_node["name"]]).issubset(set(prev_node_list)):
                print (task_node["name"])
                if set(edge_defn[task_node["name"]]).issubset(set(prev_node_list)) :  
                    tasknodes.append(task_node)
                    print ("tasknodes", tasknodes)
                
            
        if  len(tasknodes) > 0:
            
            tool_result_futures = [perform_tool_calls(task_node,tool_call_master,tool_input_transformer,agent, memory_store) for task_node in tasknodes]
            for fut in tool_result_futures:
                fut.result()
            #prev_node_list.clear()
            for task_node in tasknodes :
                prev_node_list.append(task_node["name"])
            tasknodes.clear()
        
        i=i+1

    output=None
    if  "output_transformer" in tooldata :
        output_transformer =  tooldata["output_transformer"] 
        logger.debug("output_transformer-----{}  \n",
                            output_transformer )

        output=jsonTransformer(output_transformer,tool_call_master)
        logger.debug("Final output-----{}  \n",
                            output )

    else:  
        output=tool_call_master[prev_node_list[0]]

    if "id" in tool_call :

        return {"tooldata": tooldata,
            "message": ToolMessage(content=output, tool_call_id=tool_call["id"])}
    else:
        return {"value":output, "save":output}

@task
def perform_tool_calls(task_node,tool_call_master:dict,tool_input_transformer:dict,agent:Agent, memory_store: BaseStore):

    
    logger.info("processWorkflow ----Agent Name ---{}, tool name-----{} ",
                    agent["name"],task_node["name"] )
    
    toolcalltransformer =tool_input_transformer[task_node["name"]]["inputs"]
    if toolcalltransformer !="":
        tool_call_args=jsonTransformer(toolcalltransformer,tool_call_master)  
        
        if "iterate" in tool_input_transformer[task_node["name"]]:
            iterable_values = tool_call_args[tool_input_transformer[task_node["name"]]["iterate"]]
            print("iterable_values---", iterable_values)
            results=[]
            for item in iterable_values:
                print ("item---------", item)
                tool_call_args[tool_input_transformer[task_node["name"]]["iterate"]]=item
                print("tool_call_args---------",tool_call_args)
                results.append(tool_calls(task_node,tool_call_args,agent, memory_store).result())    
            
            tool_call_master[task_node["name"]]=results
            return tool_call_master
    
    
    if  task_node["interrupt"] :
        feedback=human_feedback(task_node["interrupt_message"]).result()
        logger.debug("Tool Message-----{} \n",
                    feedback )

        if feedback=="No":
            exit()

    if task_node["type"]=="vectorsearchtool":
        result= vectorSearchToolCall(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result )
    
    if task_node["type"]=="vectoruploadtool":
        result= VectorUploadtoolcall(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result )
    
    if task_node["type"]=="llmtool":
        result= llmToolCall(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result)
    
    if task_node["type"]=="apptool":
        result = call_App_tool(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result )

    
    if task_node["type"]=="localtool":
        print("tool_call_args--------------------",tool_call_args)
        try:
            result = call_local_tool(task_node,tool_call_args,agent, memory_store).result() 

            logger.debug("Tool Message-----{}  \n",
                    result )
        except Exception as e:
            print(e)
      
    tool_call_master[task_node["name"]] =result
    return tool_call_master

@task
def tool_calls(task_node,tool_call_args:dict,agent:Agent, memory_store:BaseStore):

    logger.info("tool_calls ----Agent Name ---{}, tool name-----{} ",
                    agent["name"],task_node["name"] )

    if  task_node["interrupt"] :
        feedback=human_feedback(task_node["interrupt_message"]).result()
        logger.debug("Tool Message-----{} \n",
                    feedback )

        if feedback=="No":
            exit()

    if task_node["type"]=="vectorsearchtool":
        result= vectorSearchToolCall(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result )
    
    if task_node["type"]=="vectoruploadtool":
        result= VectorUploadtoolcall(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result )
    
    if task_node["type"]=="llmtool":
        result= llmToolCall(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result)
    
    if task_node["type"]=="apptool":
        result = call_App_tool(task_node,tool_call_args,agent, memory_store).result() 
        logger.debug("Tool Message-----{} \n",
                    result )

    
    if task_node["type"]=="localtool":
        print("tool_call_args--------------------",tool_call_args)
        try:
            result = call_local_tool(task_node,tool_call_args,agent, memory_store).result() 

            logger.debug("Tool Message-----{}  \n",
                    result )
        except Exception as e:
            print(e)

    return result
    
