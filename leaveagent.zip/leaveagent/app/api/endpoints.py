from typing import Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from langgraph.types import interrupt, Command
from app.core.workflow_controller import workflow
from app.utils.config_loader  import app_config
from sqlalchemy.orm import Session
from loguru import logger

def get_db():
    db = app_config.get_session()
    try:
        yield db
    finally:
        db.close()
router = APIRouter()




class WorkflowRequest(BaseModel):
    workflow_name: str
    session_id: Optional[str] = None
    tenant_id: Optional[str] = None
    message: Optional[str] = None
    interrupt_response: Optional[str] = None  
    profile_data: dict


@router.post("/execute_workflow")
async def execute_workflow(request: WorkflowRequest, db: Session = Depends(get_db)):
    # Here you can call your existing Python code to execute the workflow
    try:

        logger.info("execute_workflow ---{} ", request)

        if request.session_id is None:
            request.session_id = str(uuid.uuid4())

        if request.message is None:
            request.message = "Please perform the tasks"

        if request.tenant_id is None:
            request.tenant_id = "common"

        input_message = {"role": "user", "content": request.message}    

    # Invoke the workflow with the given word using the same thread ID.
        if request.interrupt_response!= None:
            workflow_result = workflow.invoke(input=
                Command(resume=request.interrupt_response), config={"configurable": {"thread_id": request.session_id,
                                                        "workflow": request.workflow_name ,
                                                        "profileData":request.profile_data}})
        else:    
            workflow_result = workflow.invoke(input=input_message, config={"configurable": {"thread_id": request.session_id,
                                                        "workflow": request.workflow_name ,
                                                        "profileData":request.profile_data}})    
                                                        #"profileData":{"tenant_id":"1","employee_id":"1000"}}})
                                                        #"profileData":{"tenant_id":"1","candidate_name":"Mary Gomez","offer_id":"666"}}})
        if workflow_result is not None:
            result = {"workflow_name":request.workflow_name, "session_id":request.session_id, 
                      "tenant_id":request.tenant_id, "profile_data":request.profile_data}
            last_state = workflow.get_state({"configurable": {"thread_id": request.session_id,"workflow": request.workflow_name,
            "profileData":request.profile_data}})
            # Try to extract the interrupt payload via the state's helper (if available).

            interrupt_state = getattr(last_state, "interrupts",  None)
            if len(interrupt_state) > 0:

                interrupt_message=interrupt_state[0].value
                result["result"]={"interrupt_message":interrupt_message}
                return result    
        '''
        if result is None:
            result = workflow.get_state({"configurable": {"thread_id": request.session_id}})
        '''
        if hasattr(workflow_result,"content"):
            print(workflow_result.content )
            final_result=workflow_result.content
        else:
            final_result=workflow_result
            for k,v in final_result.items():
                print (k)
                print ("-----------------")
                print (v)
                print("--------------------------------------------------")    
        
        result["message"] =final_result
        return {"status": "success", "result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
