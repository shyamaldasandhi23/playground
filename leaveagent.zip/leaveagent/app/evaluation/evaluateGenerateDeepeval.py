from deepeval.dataset import EvaluationDataset
from deepeval.models.llms import AzureOpenAIModel
from deepeval.synthesizer import Synthesizer
import basicconfig
import os
from deepeval.models.embedding_models.azure_embedding_model import AzureOpenAIEmbeddingModel
from typing import List, Optional
from deepeval.models import DeepEvalBaseEmbeddingModel
from deepeval.key_handler import KeyValues, KEY_FILE_HANDLER
from openai import AzureOpenAI, AsyncAzureOpenAI
from deepeval.synthesizer.config import (
    FiltrationConfig,
    EvolutionConfig,
    StylingConfig,
    ContextConstructionConfig,
)
from dotenv import load_dotenv

basicconfig
model = AzureOpenAIModel(
    deployment_name="CHROMA-GPT35",  # or your deployment
    openai_api_version="2025-01-01-preview",  # or your api version
    timeout=60,
    temperature=0,
    max_retries=2
    # other params...
)


class AzureOpenAIEmbeddingModelCustom(DeepEvalBaseEmbeddingModel):
    def __init__(self,openai_api_version,azure_embedding_deployment ):
        self.azure_openai_api_key = os.getenv('AZURE_OPENAI_API_KEY')
        self.openai_api_version = openai_api_version
        
        self.azure_embedding_deployment = azure_embedding_deployment
        self.azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
        self.model_name = self.azure_embedding_deployment

    def embed_text(self, text: str) -> List[float]:
        client = self.load_model(async_mode=False)
        response = client.embeddings.create(
            input=text,
            model=self.azure_embedding_deployment,
        )
        return response.data[0].embedding

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        client = self.load_model(async_mode=False)
        response = client.embeddings.create(
            input=texts,
            model=self.azure_embedding_deployment,
        )
        return [item.embedding for item in response.data]

    async def a_embed_text(self, text: str) -> List[float]:
        client = self.load_model(async_mode=True)
        response = await client.embeddings.create(
            input=text,
            model=self.azure_embedding_deployment,
        )
        return response.data[0].embedding

    async def a_embed_texts(self, texts: List[str]) -> List[List[float]]:
        client = self.load_model(async_mode=True)
        response = await client.embeddings.create(
            input=texts,
            model=self.azure_embedding_deployment,
        )
        return [item.embedding for item in response.data]

    def get_model_name(self) -> str:
        return self.model_name

    def load_model(self, async_mode: bool = False):
        if not async_mode:
            return AzureOpenAI(
                api_key=self.azure_openai_api_key,
                api_version=self.openai_api_version,
                azure_endpoint=self.azure_endpoint,
                azure_deployment=self.azure_embedding_deployment,
            )
        return AsyncAzureOpenAI(
            api_key=self.azure_openai_api_key,
            api_version=self.openai_api_version,
            azure_endpoint=self.azure_endpoint,
            azure_deployment=self.azure_embedding_deployment,
        )



synthesizer = Synthesizer(model=model                    
                          )

dataset = EvaluationDataset()

dataset.generate_goldens_from_docs(
    synthesizer=synthesizer,
    document_paths=["C:\\Users\\Mahesh\\work\\agenticplatform\\offerletterJuan.txt"],
    context_construction_config=ContextConstructionConfig(embedder=AzureOpenAIEmbeddingModelCustom(openai_api_version="2025-01-01-preview",
                                            azure_embedding_deployment="text-embedding-3-large"),
                                            critic_model=model)

)

dataset.save_as("csv",os.path.join(os.path.dirname(__file__)))