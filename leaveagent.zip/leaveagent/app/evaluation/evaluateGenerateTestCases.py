from llama_index.core import SimpleDirectoryReader
from agent_llm import createLLMObject
from langchain_openai import AzureChatOpenAI,AzureOpenAIEmbeddings
import os
from ragas.testset import TestsetGenerator
import basicconfig  
#from ragas.testset.evolutions import simple, multi_context, conditional
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from ragas.testset.graph import KnowledgeGraph
from ragas.testset.graph import Node, NodeType
from ragas.testset.transforms import default_transforms, apply_transforms
from ragas.testset.transforms import HeadlinesExtractor, HeadlineSplitter, KeyphrasesExtractor
from ragas.testset.persona import Persona



basicconfig
llm = AzureChatOpenAI(
    azure_deployment="CHROMA-GPT35",  # or your deployment
    api_version="2025-01-01-preview",  # or your api version
    temperature=0,
    # other params...
)

embed_model = AzureOpenAIEmbeddings( api_version="2025-01-01-preview",
                                            azure_deployment="text-embedding-3-large"
                                            )


documents = SimpleDirectoryReader(input_files=["C:\\Users\\Mahesh\\work\\agenticplatform\\offerletterJuan.txt"],
                                  ).load_data()



generator_llm = LangchainLLMWrapper(langchain_llm=llm)
generator_embeddings = LangchainEmbeddingsWrapper(embeddings=embed_model)

from ragas.testset.synthesizers.single_hop.specific import (
    SingleHopSpecificQuerySynthesizer,
)

query_distibution = [
    (
        SingleHopSpecificQuerySynthesizer(llm=generator_llm, property_name="headlines"),
        0.5,
    ),
    (
        SingleHopSpecificQuerySynthesizer(
            llm=generator_llm, property_name="keyphrases"
        ),
        0.5,
    ),
]

kg = KnowledgeGraph()


for doc in documents:
    kg.nodes.append(
        Node(
            type=NodeType.DOCUMENT,
            properties={"page_content": doc.get_content(), "document_metadata": doc.metadata}
        )
    )

headline_extractor = HeadlinesExtractor(llm=generator_llm, max_num=20)
headline_splitter = HeadlineSplitter(max_tokens=1500)
keyphrase_extractor = KeyphrasesExtractor(llm=generator_llm)

transforms = [
    headline_extractor,
    headline_splitter,
    keyphrase_extractor
]

apply_transforms(kg, transforms=transforms)


persona_candidate_sure = Persona(
    name="Candidate who wants join organisation",
    role_description="Candidate Wants to understand each and every" \
    " clause, benefits, work schedules etc mentioned in the offer letter in better way." \
    " Has many question regarding offer letter. ",
)


persona_candidate_not_sure = Persona(
    name="Candidate who has concerns about company policy",
    role_description="Candidate has aprehensions about allowances, policies and bonds etc ",
)
#distributions = {simple: 0.5, multi_context: 0.25, conditional: 0.25}

try:
    generator = TestsetGenerator(llm=generator_llm, embedding_model=generator_embeddings
                                 ,knowledge_graph=kg, persona_list=[persona_candidate_sure,persona_candidate_not_sure])
    #dataset = generator.generate_with_llamaindex_docs(documents, testset_size=10, 
    #                                                 with_debugging_logs=True)

    dataset =generator.generate(testset_size=10, query_distribution=query_distibution)
    dataset.to_pandas()

except Exception as e:
    print (e)

dataset.to_csv(os.path.join(os.path.dirname(__file__), 'test_datasets_llm_apps.csv'))


#print("dataset-------------", dataset)

