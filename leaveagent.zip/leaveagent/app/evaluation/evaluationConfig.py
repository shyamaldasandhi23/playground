config = [{
    "agent":{
        "name":"weather_assistant",
        "type": "primary",
        "profileParams":{"tenanat_id":"string","employee_id":"string"},
        "llmconfig":{
              "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
        "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},

    }}]