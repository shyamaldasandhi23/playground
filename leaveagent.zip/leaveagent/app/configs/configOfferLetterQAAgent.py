workflow =    {
    "type":"agentic",
    "agents":
    [{
    "agent":{
        "name":"offer_letter_QA_assistant",
        "type": "primary",
        "tool_concurrency":1,
        "profileParams":{"tenanat_id":"string","metadata":"dict","candidate_name":"string"},
        "llmconfig":{
              "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
        "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
        "prompt": "You are a specialized assistant for handling candidate queries regarding offer letter. "
               " When searching, be persistent. Expand your query bounds if the first search returns no results. "
             " Remember that you need to use tools appropriately to answer candidate query. you need to get candidate name from the user"
             " for running tools. If the tools give error message that some fields are missing then get that information from user"
             " please do not make up your own data for running the tool"
             "\nCurrent time: {time}."
             "\n The answer to the candidate's query should be always from the data you were given by the tool"
              "Important Instruction: user cannot change candidate name in between. Candidate name cannot change"
              ,
        "tools":  {
            "toolsdesc":
                [{"name": "offer_letter_info_retriever",                
                "description": "Retrieves the information of the offer letter for a particular candidate "
                "based on dict object made up of candidate name and offer id ",
                "parameters": {
                "type": "object",
                "properties": {
                "metadata": {
                "type":"object",
                "description": "This is the dict object made up (candidate_name, offer_id) for e.g"
                " candidate_name:john doe, offer_id:12121",
                "properties": {
                    "offer_id": {
                        "type":"string",
                        "description": "Value of offer id should not be changed once it is provided by user"

                    },
                    "candidate_name":{
                        "type":"string",
                        "description": "Value of candidate name should not be changed once it is provided by user"

                    }}
                },
                "query": {
                "type": "string",
                "description": "This the query or information that employee needs answer for"
                },
                },
                "required": ["metadata","query"],

                }}
                ,
                {"name": "get_candidate_offer_letter_id",                
                "description": "this tool gets the candidate name and tenant id as input and returns candidate dict of offer_id and name which is used"
                "for getting information from offer letter ",
                "parameters": {
                "type": "object",
                "properties": {
                "candidate_name": {
                "type": "string",
                "description": "The candidate name is the name of the candidate asking questions about offer letter"
                " Value of candidate name should not be allowed to be changed once it is provided by user"
               
                },                
                "tenant_id": {
                "type": "string",
                "description": " tenant id of the organisation to which this candidate belongs to"
                }
                },
                "required": ["candidate_name","tenant_id"]

                }}
                ],    
            "toolsmetadata":[{
                "name": "offer_letter_info_retriever",
                "type":"vectorsearchtool" , 
                "interrupt":False,
                "collection_id":"demo_vector",
                "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
                "filtertransformer":"{candidate_name:.[2].candidate_name,offer_id:.[2].offer_id}",
                }
                ,
                {
                "name": "get_candidate_offer_letter_id",
                "type":"localtool" , 
                "interrupt":False,
                "interrupt_message":"Give feedback",
                }
                ]}          
                        
        }
        },
    ]

}