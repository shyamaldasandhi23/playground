workflow ={

    "type":"workflow",
    "name":"handle_experience_Scoring",
    "mode":"predefined",
    "output_transformer":"{Resume_Summary: .resume_experience_scorer}",
    "task_nodes":[
            {
            "name":"resume_info_retriever_skills",
            "type":"vectorsearchtool" , 
            "tool_call_transformer":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}}",
            "query":"name of candidate, skills, education , certifications and professional summary ",
            "interrupt":False,
            "collection_id":"resume_vector",
            "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
            "filtertransformer":"{candidate_name:.[1].args.candidate_name,tenant_id:.[1].args.tenant_id}",
            "filtercondition":"and"
            },
            {
            "name": "get_skills_certification_weightages",
            "type":"llmtool",
            "interrupt":False,
            "tool_call_transformer":"{ resume_info: .resume_info_retriever_skills.result_text}",
            "llmconfig":{
                "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
            "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
            "message":"Your work is to throughly understand and identify the skills mentioned in the resume by the candidate"
            " and the certification done by the candidate."
            " Skills identified should be a mix of technical skills for e.g Python developer, Mainframe developer, java Developer, Solution Architecture, Devops , Generative AI etc"
            " and also managerial skills relevant for job like problem solving , communication , leading team etc."
            " Maximum of 7 most required skills for the job should be identified. "
            " You Assign the weightages to each skill with sum total of 100 , considering whether role mentioned is managerial or technical. "
            " Decimal score for weightage is not allowed."
            " you then create following as output"
            " 1. Skills vs weightages tables "
            " 2. Education and certification Information"
            " 3. Name of the candidate"
            },
            {
            "name":"resume_info_retriever",
            "type":"vectorsearchtool" , 
            "tool_call_transformer":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}}",
            "query":"Professional experience with roles and professional summary ",
            "interrupt":False,
            "collection_id":"resume_vector",
            "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
            "filtertransformer":"{candidate_name:.[1].args.candidate_name,tenant_id:.[1].args.tenant_id}",
            "filtercondition":"and"

            },
            {                                               
            "name": "resume_experience_scorer",
            "type":"llmtool",
            "interrupt":False,
            "tool_call_transformer":"{skills_certification_details: .get_skills_certification_weightages, resume_experience_info: .resume_info_retriever.result_text}",
            "llmconfig":{
                "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
            "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
            "message":"You have been given 3 inputs 1.e."
            " 1. Skills vs weightages tables "
            " 2. Education and certification Information"
            " 3. Experience Summary mentioned in resume"
            " Your job is to throughly go through the experience summary mentioned in resume, understand"
            " the education and certification and then create a intermediate information for step by step evaluation of resume"
            "1. skills vs score matrix. Be very objective while evaluating. It should be based on following critieria"
                "Score 8-10 is excellent match between skills and scrore and certifications, score 5-7 is good match and less than 5 is average match "
            " The final output from you should consist of following"
            " A. A table of Weighted score skill1:score1 * weightage, Skill2: score2 * weightage, Skill3: score3 * weightage}})"                
                " example calculation e.g weighted_score_for_skill1 = 150 if score value is 5 and weight is 30 then 5*30=150 , weighted_score_for_skill2=270 if score value is 6 and weight is 45 then 6*45=270, "
                " weighted_score_for_skill3=100 if score value is 4 and weight is 25 then 25*4=100...so on and so forth"           
            " B. Concise explaination of scores assigned to each skill with citing/references to resume snippets "
            " C. Education and certification Information"   
            " D. Name of the candidate"     
            }
            ,
            {
            "name":"resume_summary_uploader",
            "type":"vectoruploadtool" , 
            "tool_call_transformer":"{text: .resume_experience_scorer,candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}",
            "interrupt":False,
            "collection_id":"resume_summary_vector",
            "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
            "metadatatransformer":"{candidate_name:.[1].candidate_name,tenant_id:.[1].tenant_id}",
            },

            
            ]
            ,
    "edge_defn":
        {"resume_info_retriever_skills":["start"],
        "get_skills_certification_weightages":["resume_info_retriever_skills"],
        "resume_info_retriever":["resume_info_retriever_skills"],
        "resume_experience_scorer":["get_skills_certification_weightages","resume_info_retriever"],
        "resume_summary_uploader":["resume_experience_scorer"],
        }
        ,
     "input_transformer":
     {
        "resume_info_retriever_skills": {"inputs":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}}"},
        "get_skills_certification_weightages":{"inputs":"{ resume_info: .resume_info_retriever_skills.result_text}"},
        "resume_info_retriever":{"inputs":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}}"},
        "resume_experience_scorer" :{"inputs":"{skills_certification_details: .get_skills_certification_weightages, resume_experience_info: .resume_info_retriever.result_text}"},
        "resume_summary_uploader" : {"inputs":"{text: .resume_experience_scorer,candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}"},                                    
     }   
    }
