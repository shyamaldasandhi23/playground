workflow = {

    "type":"agentic",
    "agents":
    [{
    "agent":{
        "name":"Master_assistant",
        "type": "primary",
        "tool_concurrency":1,
        "profileParams":{"tenanat_id":"string","employee_id":"string"},
        "llmconfig":{
              "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
        "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
        "prompt": "You are a specialized assistant for handling user queries regarding weather. "
               " When searching, be persistent. Expand your query bounds if the first search returns no results. "
             " Remember that you need to use tools appropriately to answer user query. dont create own data for running tools"
             " ask for data from user if data is incomplete for running tools"
             " please look at conversation history and then decide."
             " for leave related queries from employees, handover to handleLeaveQueries"
             " for offer letter queries like company policies, Position Title, Job Description,Compensation, ctc,Benefits,"
            " Start Date, Work Schedule,Reporting Structure,Probation Period,Confidentiality Agreement"
            ", Non-Compete Clause,Termination Conditions,Signature etc handover to handleOfferLetterQueries "
             "\nCurrent time: {time}."
             "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
             "Do not waste the user\'s time. Do not make up invalid tools or functions."
              ,
        "tools":  {
            "toolsdesc":
                [{"name": "check_weather",                
                "description": "Return the weather forecast for the specified location.",
                "parameters": {
                "type": "object",
                "properties": {
                "location": {
                "type": "string",
                "description": "The location of the place"
                }
                }}}
                ,
                {"name": "handleLeaveQueries",
                "description": "This is leave related asssistant. It handles leave queries from employees like leave balance, "
                                "apply for leave",
                "parameters": {
                    "type":"object",
                    "properties":{}
                }}
                ,
                {"name": "handleOfferLetterQueries",
                "description": "This is Offer letter question answer asssistant."
                " It handles, offer leter related queries from candidate company policies, Position Title, Job Description,Compensation, ctc,Benefits,"
            " Start Date, Work Schedule,Reporting Structure,Probation Period,Confidentiality Agreement"
            ", Non-Compete Clause,Termination Conditions",
                "parameters": {
                    "type":"object",
                    "properties":{}
                }}
                ],    
            "toolsmetadata":[{
                "name": "check_weather",
                "type":"localtool" , 
                "interrupt":False,
                "interrupt_message":"Give feedback",
                },
                {
                "name": "handleLeaveQueries",
                "assistant_name":"Leave_Assistant",
                "type":"assistanthandover",
                "toolmessage":"The query is not related to your subject matter,"
                 "so the conversation with user is already handed over to other specialised assistant which is leave_assistant"
                 " you dont have to mention to user about this internal transfer between assistants."                  
                }
                ,
                {
                "name": "handleOfferLetterQueries",
                "assistant_name":"offer_letter_QA_assistant",
                "type":"assistanthandover",
                "toolmessage":"The query is not related to your subject matter,"
                 "so the conversation with user is already handed over to other specialised assistant which is offer_letter_QA_assistant"
                 " you dont have to mention to user about this internal transfer between assistants."                                    
                }
                ]}          
                        
        }
        },
        {
        "agent":{
        "name":"Leave_Assistant",
        "type": "crew",
        "llmconfig":{
              "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
        "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
        "prompt": "You are a specialized assistant for handling leave related queries and leave requests from employees. "
             " When searching, be persistent. Expand your query bounds if the first search returns no results. "
             " Remember that you need to use tools appropriately to answer user query and take actions on leave requests."
             " Make sure you have enough data for running appropriate tool. Dont create your own data for running tools"
             " If data is not received from a particular tool or particular tool gives error message then "
             " apologize to user for not being able to help currently with the given request and advice to try later"
             "\nCurrent time: {time}."
             "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
              " Do not waste the user\'s time. Do not make up invalid tools or functions."
             "if the queries is not related to leaves or related to offer letter give back control to master assisant i.e. handleEscalation without asking user"
              ,
        "tools":  {
            "toolsdesc":
                [
                {"name": "getLeaveBalance",
                "description": "This is the tool to get leave balance for an employee. This does not require any input from user",
                "parameters": {
                "type": "object",
                "properties": {}
                
                }}
                ,
                {"name": "validate_Leave_Balance_For_Request",
                "description": "This is tool to validate whether the employee has enough leave balance vs the number of days"
                    "he wants to apply leave for",
                "parameters": {
                "type": "object",
                "properties": {
                "leave_balance": {
                "type": "string",
                "description": "this is the leave balance of the employee "
                },
                 
                "required_leave_days": {
                "type": "string",
                "description": "this is the number of days employee wants to apply for leave "
                }
                }}}
                ,{"name": "apply_For_Leave_After_Validation",
                "description": "This is tool to apply the leave for employee if the employee has enough leave balance",
                "parameters": {
                "type": "object",
                "properties": {
                "required_leave_days": {
                "type": "string",
                "description": "this is the number of days employee wants to apply for leave "
                }
                }}}

                ,
                {"name": "handleEsclation",
                "description": "This tool handles queries which you cannot answer or not related to you subject matter",
                "parameters": {
                    "type":"object",
                    "properties":{}
                }}
                ],    
            "toolsmetadata":[{
                "name": "handleEsclation",
                "assistant_name":"Master_assistant",
                "type":"masterhandover",
                "toolmessage":"The query is not related to your subject matter,"
                 "so the conversation with user is already handed over to master assistant which is Master_assistant. "
                 "Master assistant will answer the query. No tool call from your side"
                 },

                {
                "name": "getLeaveBalance",
                "type":"apptool",
                "base_url":"http://127.0.0.1:8000",
                "end_point":"get_leave_balance",
                "method":"POST",
                "jsontransformer":"{employee_id: .[2].candidate_name,tenant_id:.[2].tenant_id}",
                "interrupt":False,
                },               
                {
                "name": "validate_Leave_Balance_For_Request",
                "type":"localtool",
                "interrupt":False,
                },
                
                {
                "name": "apply_For_Leave_After_Validation",
                "type":"localtool",
                "interrupt":True,
                "interrupt_message":"Should I apply for Leave, Please confirm"
                }
                ]}          
                        
        }
        }, 
        {
        "agent":{
        "name":"offer_letter_QA_assistant",
        "type": "crew",
        "profileParams":{"tenanat_id":"string","metadata":"dict","candidate_name":"string"},
        "llmconfig":{
              "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
        "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
        "prompt": "You are a specialized assistant for handling candidate queries,"
            "  regarding offer letter only like company policies, Position Title, Job Description,Compensation, ctc,Benefits,"
            " Start Date, Work Schedule,Reporting Structure,Probation Period,Confidentiality Agreement"
            ", Non-Compete Clause,Termination Conditions,Signature etc"
             " Remember that you need to use tools appropriately to answer candidate queries regarding offer letter."
             " You need to get candidate name from the human feedback, for running tools. "
             "If the tools give error message that some fields are missing then get that information from human feedback."
             " Do not create your own data like candidate name Alice etc for running the tool."
             "\nCurrent time: {time}."
             "\n The answer to the candidate's query should be always from the data you were given by the tool "
              "if the queries are not related to offer letter or data provided is not related give back control to master assisant i.e. handleEscalation without asking user"
              ,
        "tools":  {
            "toolsdesc":
                [{"name": "offer_letter_info_retriever",                
                "description": "Retrieves the information inside the offer letter for a particular candidate "
                "based on dict object made up of candidate name and offer id ",
                "parameters": {
                "type": "object",
                "properties": {
                "metadata": {
                "type":"object",
                "description": "This is the dict object made up (candidate_name, offer_id) ",
                "properties": {
                    "offer_id": {
                        "type":"string",
                        "description": "Value of offer id should not be changed once it is provided by user"

                    },
                    "candidate_name":{
                        "type":"string",
                        "description": "Value of candidate name should not be changed once it is provided by user"

                    }}
                },
                "query": {
                "type": "string",
                "description": "This the query or information that employee needs answer for"
                },
                },
                "required": ["metadata","query"],

                }}
                ,
                {"name": "get_offer_letter_id",                
                "description": "Gets the infomation about the correct offer letter for the candidate. input to this tool is candidate name which you have to get from human feedback. ",
                "parameters": {
                "type": "object",
                "properties": {
                "candidate_name": {
                "type": "string",
                "description": "The field is provided by the human/user"
    
                }
                },
                "required": ["candidate_name"]

                }}
                ,
                {"name": "handleEscalation",
                "description": "This tool handles queries which you cannot answer or not related to you subject matter like leave related queries",
                "parameters": {
                    "type":"object",
                    "properties":{}
                }}
                ],    
            "toolsmetadata":[{
                "name": "offer_letter_info_retriever",
                "type":"vectorsearchtool" , 
                "interrupt":False,
                "collection_id":"demo_vector",
                "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
                "filtertransformer":"{candidate_name:.[2].candidate_name,offer_id:.[2].offer_id}",
                "filtercondition":"and"

                }
                ,
                {
                "name": "get_offer_letter_id",
                "type":"localtool" , 
                "interrupt":False,
                "interrupt_message":"Give feedback",
                }
                ,
                {
                "name": "handleEscalation",
                "assistant_name":"Master_assistant",
                "type":"masterhandover",
                "toolmessage":"The query is not related to your subject matter,"
                 "so the conversation with user is already handed over to master assistant which is Master_assistant"
                "Master assistant will answer the query. No tool call expected from your side"
                },
                ]}          
                        
        }
        },

    ]
}
