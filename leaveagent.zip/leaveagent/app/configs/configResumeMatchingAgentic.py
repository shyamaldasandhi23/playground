workflow ={

    "type":"agentic",
    "agents":[
    {
    "agent":{
        "name":"Resume_vs_JD_Matching_scoring_Agent",
        "type": "primary",
        "tool_concurrency":3,
        "llmconfig":{
              "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
        "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
        "prompt": 
            "You are a specialized assistant that assesses the suitability of a candidate for "
            "a given job by matching the candidate's resume with the requirements mentioned in the job description (JD). "
        ,
        "tools":  {
            "toolsdesc":
                [{"name": "perform_candidate_Scoring",                
                "description": "This tool gets query as input for which resume data is extracted and matched with job description"
                "query e.g.  skills. This tool also performs scoring of skilis vs job description matching"
                " Very Imp: This function is not designed for parallel execution.",
                "parameters": {
                "type": "object",
                "properties": {
                "query": {
                "type": "string",
                "description": "The candidate name is the name of the candidate asking questions about offer letter"
                " Value of candidate name should not be allowed to be changed once it is provided by user"
                " JD and resume are made available to tools. So dont worry about that."
                }
                }}
                }
                ],    
            "toolsmetadata":[
                {
                "type":"workflow",
                "name":"perform_candidate_Scoring",
                "interrupt":False,
                "output_transformer":"{experience_score: .compare_jd_vs_resume_experience, skills_score: .compare_jd_vs_resume_skills}",
                "mode":"predefined",
               "task_nodes":[
        
                {
                    "name": "get_job_description",
                    "type":"localtool" , 
                    "interrupt":False,
                    "tool_call_transformer":"{}",

                },
                {
                    "name": "generate_prompt",
                    "type":"llmtool",
                    "interrupt":False,
                    "llmconfig":{
                        "llm_module_name": "langchain_openai",
                        "llm_pkg_name": "",
                        "llm_class_name": "AzureChatOpenAI" },
                    "llmattr":{
                        "azure_deployment":"CHROMA-GPT35",  # or your deployment
                        "api_version":"2025-01-01-preview",  # or your api version
                        "temperature":0,
                        "max_tokens":None,
                        "timeout":None,
                        "max_retries":2},
                    "message":"Your role is a prompt generator but you should never mention that it is a generated prompt."
                    " Your have been given Job Description. Study the job description thoroughly. "
                    " Identify maximum 6 skills relevant for job which candidate should clearly align with Job Description and especially job title. "
                    " Skills identified should be a mix of technical skills for e.g Python developer, java Developer, Solution Architecture, Devops , Generative AI etc"
                    " and also managerial skills relevant for job like problem solving , communication , leading team etc."
                    " Maximum of 6 most required skills for the job should be identified. "
                    " You Assign the weightages to each skill with sum total of 100 , as per job description and considering whether role required is managerial or technical. "
                    " decimal score for weightage is not allowed"
                    " You should then generate a prompt for the LLM (comparator assistant ) with following information"
                    " 1. Skills vs weightages tables you created "
                    " 2. Ask: Compare experience or skills mentioned in Candidate's resume vs "
                    " the requirement as per job description. Assign a score less than 10 for each skill. "
                    " Explain this clearly in prompt that Score 8-10 is excellent match, score 5-7 is good match and less than 5 is average match "
                    " generated prompt should have step by step explaination of ask." 
                    " 3. Then you explain in the expected output template in generated prompt to include 2 parts "
                    " a. A proper table of skills vs weightages. "
                    " b. A proper table of skill vs score for template skill1:score1 , skill2:score2, skill3:score3 so on and so forth. "
                    "  Mention in the prompt that Score has to be whole number. Dont assign any values to score in the generated prompt just explain template."
                    " c. json for Weighted score with following template  { \"detailed_Score\":{\"skill1\":score1 * weightage, Skill2: score2 * weightage, Skill3: score3 * weightage}})"
                    " d. Final_Score is addition of all detailed_scores and should not exceed 1000. Just explain this json template here with formula not values for all identified skills"
                    " 4. Then add this section marked between pair of '///' in generated LLM as is, to explain example calculations for filling json values with all identified skills "
                    " ///e.g. steps for calculating final_sumed_score are as follows"
                    " 4.1 Multiplication of score * weight e.g weighted_score_for_skill1 = 150 if score value is 5 and weight is 30 then 5*30=150 , weighted_score_for_skill2=270 if score value is 6 and weight is 45 then 6*45=270, "
                    "   weighted_score_for_skill3=100 if score value is 4 and weight is 25 then 25*4=100...so on and so forth"
                    " 4.2 Then final_sumed_score is mathematical addition of weighted_score_for_skill1 + weighted_score_for_skill2 + weighted_score_for_skill3  i.e. 150 + 270 +100 = 520 "
                    " Clearly mention that values mentioned are for example/illustration purpose only /// "
                    " 5. Special Instructions to be included in generated prompt"
                    " While explaining output requirement emphasize that comparator LLM should explain calculations with actual scores and weightage values "
                    " along with all mathematical operation especially for final_sumed_score in the output. Revalidate them thoroghly"
                    " Also in generated prompt ask comparator LLM to always provide explaination for giving particular score value for a given skill by citing/referring resume snippets "
                    " while explaining \"ask\" in the generated prompt ,do mention that scoring should be judicious and explained in output ."        
                    },

                    {
                    "name":"resume_info_retriever",
                    "type":"vectorsearchtool" , 
                    "query":"Professional experience with roles and professional summary ",
                    "interrupt":False,
                    "collection_id":"resume_vector",
                    "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
                    "filtertransformer":"{candidate_name:.[1].args.candidate_name,tenant_id:.[1].args.tenant_id}",
                    },
                    {
                    "name": "compare_jd_vs_resume_experience",
                    "type":"llmtool",
                    "interrupt":False,
                    "llmconfig":{
                        "llm_module_name": "langchain_openai",
                        "llm_pkg_name": "",
                        "llm_class_name": "AzureChatOpenAI" },
                    "llmattr":{
                        "azure_deployment":"CHROMA-GPT35",  # or your deployment
                        "api_version":"2025-01-01-preview",  # or your api version
                        "temperature":0,
                        "max_tokens":None,
                        "timeout":None,
                        "max_retries":2},
                    },

                    {
                    "name":"resume_info_retriever_skills",
                    "type":"vectorsearchtool" , 
                    "query":"Professional skills with roles and professional summary ",
                    "interrupt":False,
                    "collection_id":"resume_vector",
                    "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
                    "filtertransformer":"{candidate_name:.[1].args.candidate_name,tenant_id:.[1].args.tenant_id}",
                    },
                    {
                    "name": "compare_jd_vs_resume_skills",
                    "type":"llmtool",
                    "interrupt":False,
                    "llmconfig":{
                        "llm_module_name": "langchain_openai",
                        "llm_pkg_name": "",
                        "llm_class_name": "AzureChatOpenAI" },
                    "llmattr":{
                        "azure_deployment":"CHROMA-GPT35",  # or your deployment
                        "api_version":"2025-01-01-preview",  # or your api version
                        "temperature":0,
                        "max_tokens":None,
                        "timeout":None,
                        "max_retries":2},
                    },

                    ],
                "edge_defn":
                    {"get_job_description":["start"],
                    "generate_prompt":["get_job_description"],
                    "resume_info_retriever":["generate_prompt"],
                    "compare_jd_vs_resume_experience":["resume_info_retriever"],
                    "resume_info_retriever_skills":["compare_jd_vs_resume_experience"],
                    "compare_jd_vs_resume_skills":["resume_info_retriever_skills"]
                    },
                "input_transformer":
                    {"get_job_description":{"inputs":"{args:{file_name: .input.file_name}}"},
                    "generate_prompt":{"inputs":"{job_description: .get_job_description}"},
                    "resume_info_retriever":{"inputs":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}}"},
                    "compare_jd_vs_resume_experience":{"inputs":"{prompt: .generate_prompt, job_description: .get_job_description, resume_info: .resume_info_retriever.result_text}"},
                    "resume_info_retriever_skills":{"inputs":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id}}"},
                    "compare_jd_vs_resume_skills":{"inputs":"{prompt: .generate_prompt, job_description: .get_job_description, resume_info: .resume_info_retriever_skills.result_text}"}
                    }
                },

                ]}    
        }
    }
]
}


