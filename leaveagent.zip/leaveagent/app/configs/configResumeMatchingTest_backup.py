workflow ={

    "type":"workflow",
    "name":"handle_experience_Scoring",
    "mode":"predefined",
    "output_transformer":"{Resume_Summary: .compare_jd_vs_resume_skills}",
    "task_nodes":[       
             
        {
            "name": "get_job_description",
            "type":"localtool" , 
            "interrupt":False,
            "tool_call_transformer":"{}",
        }
        ,
        {
            "name": "generate_search_query",
            "type":"llmtool",
            "interrupt":False,
            "tool_call_transformer":"{job_description: .get_job_description}",
            "llmconfig":{
                "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
            "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
            "message":" Your have been given Job Description. Study the job description thoroughly. "
            " Identify maximum 7 skills relevant for job which candidate should clearly align with Job Description and especially job title. "
            " Skills identified should be a mix of technical skills for e.g Python developer, java Developer, Solution Architecture, Devops , Generative AI etc"
            " and also managerial skills relevant for job like problem solving , communication , leading team etc."
            " Maximum of 7 most required skills for the job should be identified. "
            " You Assign the weightages to each skill with sum total of 1000 , as per job description and considering whether role required is managerial or technical. "
            " decimal score for weightage is not allowed"
            " You should then generate output as follows"
            " 1. Skills vs weightages tables you created "
        },

        {
            "name":"resume_info_retriever",
            "type":"vectorsearchtool" , 
            "tool_call_transformer":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id, query: .generate_search_query}}",
            "interrupt":False,
            "collection_id":"resume_summary_vector",
            "db_id":"C:\\Users\\Mahesh\\work\\agenticplatform\\chroma-db",
            "top_k":3

            },

           {
            "name": "compare_jd_vs_resume_skills",
            "type":"llmtool",
            "interrupt":False,
            "tool_call_transformer":"{prompt: .generate_prompt, job_description: .get_job_description, resume_info: .resume_info_retriever_skills.result_text}",
            "llmconfig":{
                "llm_module_name": "langchain_openai",
                "llm_pkg_name": "",
                "llm_class_name": "AzureChatOpenAI" },
            "llmattr":{
                "azure_deployment":"CHROMA-GPT35",  # or your deployment
                "api_version":"2025-01-01-preview",  # or your api version
                "temperature":0,
                "max_tokens":None,
                "timeout":None,
                "max_retries":2},
            "message":"You have been given 3 inputs 1.e."
            " 1. Skills vs weightages tables "
            " 2. Resume with skills, experience, education and certification Information"
            " Your job is to throughly go through the experience summary mentioned in resume, understand"
            " the education and certification and then create a intermediate information for step by step evaluation of resume"
            "1. skills vs score matrix. Be very objective while evaluating. It should be based on following critieria"
                "Score 8-10 is excellent match between skills and scrore and certifications, score 5-7 is good match and less than 5 is average match "
            " The final output from you should consist of following"
            " A. A table of Weighted score skill1:score1 * weightage, Skill2: score2 * weightage, Skill3: score3 * weightage}})"                
                " example calculation e.g weighted_score_for_skill1 = 150 if score value is 5 and weight is 30 then 5*30=150 , weighted_score_for_skill2=270 if score value is 6 and weight is 45 then 6*45=270, "
                " weighted_score_for_skill3=100 if score value is 4 and weight is 25 then 25*4=100...so on and so forth"           
            " B. Concise explaination of scores assigned to each skill with citing/references to resume snippets "
            " C. Education and certification Information"   
            " D. Name of the candidate"     

            },
   
        ],
    "edge_defn":
        { "get_job_description":["start"],
          "generate_search_query":["get_job_description"],
          "resume_info_retriever":["generate_search_query"],
          "compare_jd_vs_resume_skills":["resume_info_retriever"]

        },
    "input_transformer":

        { "get_job_description":{"inputs":"{}"},
        "generate_search_query":{"inputs":"{job_description: .get_job_description}"},
        "resume_info_retriever":{"inputs":"{args:{candidate_name: .input.candidate_name,tenant_id: .input.tenant_id, query: .generate_search_query}}"},
        "compare_jd_vs_resume_skills":{"inputs":"{resumes:[.resume_info_retriever.nodes[].node.text | {resume: .}] ,job_description: .get_job_description}","iterate":"resumes"},
        }
        
}   