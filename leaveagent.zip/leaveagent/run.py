import uuid
from app.core.workflow_controller import workflow
from langgraph.types import interrupt, Command
from langchain_core.messages import BaseMessage
from app.utils.utilsForMessageDisplay import display_state_history, display_workflow_result


workflowdata='configResumeMatchingAgentic'
thread_id = str(uuid.uuid4())
print("Starting the workflow loop. Type 'quit' at any prompt to exit.\n")
while True:
    user_word = input("Enter a query: ").strip()
    if user_word.lower() == "quit":
        break
    
    input_message = {"role": "user", "content": user_word}    

    # Invoke the workflow with the given word using the same thread ID.
    result = workflow.invoke(input=input_message, debug=True,config={"configurable": {"thread_id": thread_id,
                                                        "workflow": workflowdata,
                                                        "profileData":{"tenant_id":"1212","candidate_name":"Jane Doe", "file_name": "C:\\Users\\Mahesh\\work\\agenticplatform\\jd for Gen AI architect.txt"}}})    
                                                        #"profileData":{"tenant_id":"1","employee_id":"1000"}}})
                                                        #"profileData":{"tenant_id":"1","candidate_name":"Mary Gomez","offer_id":"666"}}})
    # If the workflow was interrupted and did not complete, result will be None.

    if result is not None:
        last_state = workflow.get_state({"configurable": {"thread_id": thread_id,"workflow": workflowdata,
        "profileData":{"tenant_id":"1","employee_id":"1000"}}})
        # Try to extract the interrupt payload via the state's helper (if available).

        interrupt_state = getattr(last_state, "interrupts",  None)
        if len(interrupt_state) > 0:
            resume_value = input(
                "Please approve this request by typing 'yes': "
            ).strip()
            result = workflow.invoke(input=
            Command(resume=resume_value), config={"configurable": {"thread_id": thread_id,"workflow": workflowdata,
                                                                   "profileData":{"tenant_id":"1","employee_id":"1000"}}})
    if result is None:
        result = workflow.get_state({"configurable": {"thread_id": thread_id}})

    # Display the final draft using the utility function
    display_workflow_result(result)

    # Retrieve and display checkpoint data using the utility function
    state_history = list(
        workflow.get_state_history({"configurable": {"thread_id": thread_id,"workflow": workflowdata}})
    )
    #display_state_history(state_history)
