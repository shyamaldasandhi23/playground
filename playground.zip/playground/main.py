from nicegui import ui
import json
import httpx
from html import escape

# Initial payload
initial_payload = {
  "workflow_name": "configResumeScoreMatching",
  "tenant_id": "common",
  "session_id": "222212121222",
  "profile_data": {
    "tenant_id": "1212",
    "candidate_name": "John Doe",
    "file_name": "C:\\Users\\Mahesh\\work\\agenticplatform\\jd for Gen AI architect.txt"
  },
  "message": "hi"
}


leave_agent_payload = {
    "workflow_name": "configLeaveAgent",
    "tenant_id": "common",
    "session_id": "1121212",
    "profile_data":{"tenant_id":"1","candidate_name":"Mary Gomez","offer_id":"666"},
    "message": "Hi"
}

resume_scoring_payload={
  "workflow_name": "configResumeScoreMatching",
  "tenant_id": "common",
  "session_id": "222222",
  "profile_data": {
    "tenant_id": "1212",
    "candidate_name": "John Doe",
    "file_name": "C:\\Users\\Mahesh\\work\\agenticplatform\\jd for Gen AI architect.txt"
  },
  "message": "hi"
}


# Store messages
messages = []

# Header


with ui.header().classes('bg-white text-black shadow-md'):
    ui.label('Chroma GenAI Platform').classes('text-xl font-semibold p-2')


# Main layout
with ui.row().classes('w-full p-4 gap-4'):

    # Left panel
    with ui.column().classes('w-1/4 gap-4'):
        ui.label('Workflow Name').classes('font-semibold')
        workflow_input = ui.input(value=initial_payload["workflow_name"]).classes('w-full')

        ui.label('Input Payload').classes('font-semibold')
        payload_area = ui.textarea(value=json.dumps(initial_payload, indent=2)).classes('w-full h-64')

        def update_payload():
                # Update the workflow name in the payload
                    print("invoked",workflow_input.value)

                    if workflow_input.value == "configLeaveAgent":
                    # Update the textarea content
                        print("invoked",workflow_input.value)

                        payload_area.value=( json.dumps(leave_agent_payload, indent=2))

                    elif workflow_input.value == "configResumeScoreMatching":
                        payload_area.value=( json.dumps(resume_scoring_payload, indent=2))

                    else:    
                        payload_area.value= ( json.dumps(initial_payload, indent=2))


        workflow_input.on('blur', lambda e: update_payload())  # triggers on focus loss


    # Right panel
    with ui.column().classes('w-3/5 gap-4'):
        ui.label('Chat Section').classes('font-semibold')
        chat_window_container = ui.column().classes('w-full h-80 overflow-auto border p-2 bg-gray-50 rounded')
        chat_input = ui.input(placeholder='Type your message and press Enter...').classes('w-full')
        spinner = ui.spinner(size='lg').classes('self-center').style('display: none')

        # JSON viewer
        with ui.expansion('LLM Full Response', icon='code').classes('w-full') as json_viewer:
            json_tree = ui.textarea(label='LLM Full Response').classes('w-full h-64')

         
            
        def render_messages():
            chat_window_container.clear()
            with chat_window_container:
                for msg in reversed(messages):  # latest on top
                    ui.html(msg)

        async def send_message(e):
            user_message = chat_input.value.strip()
            if not user_message:
                return

            keyword ="interrupt_response"
            index = user_message.find(keyword)
            after_keyword = None
            # Get everything after the keyword
            if index != -1:

                after_keyword = user_message[index + len(keyword):].strip()
            else:
                print("Keyword not found.")

            # Parse and update payload
            try:

                payload = json.loads(payload_area.value)
                if after_keyword != None:
                    payload[keyword]=after_keyword
            except json.JSONDecodeError:
                messages.append('<div class="text-red-600">❌ Invalid JSON in input payload</div>')
                render_messages()
                return

            payload["workflow_name"] = workflow_input.value
            payload["message"] = user_message
            payload_area.value = json.dumps(payload, indent=2)

            spinner.style('display: block')

            try:
                async with httpx.AsyncClient(timeout=60.0) as client:
                    print("json payload" , payload)
                    res = await client.post('http://localhost:8001/execute_workflow', json=payload)
                    response_json = res.json()
                    print (response_json)
                    if (response_json.get("result", {}).get("message", None)) == None:
                        message_dict = response_json.get("result", {}).get("interrupt_message", {})
                        print("message_dict", message_dict)
                    else:    
                        message_dict = response_json.get("result", {}).get("message", {})

            except Exception as ex:
                message_dict = f"Error: {ex}"
                response_json = {"error": str(ex)}

            spinner.style('display: none')
            # Add user message in green (rendered HTML)

            # Add LLM message in blue (rendered HTML)
            if isinstance(message_dict, dict):
                combined_message = ""
                for section_name, section_text in message_dict.items():
                    escaped_name = escape(section_name)
                    if isinstance(section_text, dict):
                        escaped_text = escape(str(section_text)).replace('\n', '<br>')
                    else:        
                        escaped_text = escape(section_text).replace('\n', '<br>')
                    combined_message += f"<strong>{escaped_name}:</strong><br>{escaped_text}<br><br>"
                messages.append(f'<div class="text-blue-700">{combined_message}</div>')
            else:
                print("interrupt",message_dict)
                formatted_text = escape(str(message_dict)).replace('\n', '<br>')
                messages.append(f'<div class="text-blue-700">LLM: {formatted_text}</div>')

            escaped_user_message = escape(user_message).replace('\n', '<br>')
            messages.append(f'<div class="text-green-700"><strong>You:</strong><br>{escaped_user_message}</div>')


            render_messages()

            json_tree.value = json.dumps(response_json, indent=4)
            chat_input.value = ''

        chat_input.on('keydown.enter', send_message)




# Footer
ui.label('Created by Chroma Gen AI Team').classes('text-sm text-center text-gray-600 p-4')

ui.run()
